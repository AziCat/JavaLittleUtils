import java.io.IOException;

public class Demo {
    public static void main(String[] args) {
        String url = "http://localhost:7070/msg/send/sendMessage.action";

        Message message = new Message();
        message.setContent("消息正文");
        message.setDeadline("2018-01-01 12:00:00");
        message.setMessage_type("01");
        message.setReceiver("sylmj");
        message.setSender("leifeng");
        message.setUrl("http://ip");
        try {
            String result = HttpClintUtil.sendServiceCallRequest(url,message);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
