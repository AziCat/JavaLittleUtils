import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 消息实体
 *
 * @author yjh
 * @date 2017.09.08
 */
public class Message {

    //消息类型，字典MC_TYPE
    private String message_type;
    //消息正文
    private String content;
    //发送人
    private String sender;
    //接收人
    private String receiver;
    //链接
    private String url;
    //接收单位
    private String receive_dept;
    //消息有效期限 yyyy-MM-dd HH:mm:ss
    private String deadline;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMessage_type() {
        return message_type;
    }

    public void setMessage_type(String message_type) {
        this.message_type = message_type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getReceive_dept() {
        return receive_dept;
    }

    public void setReceive_dept(String receive_dept) {
        this.receive_dept = receive_dept;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }
}
